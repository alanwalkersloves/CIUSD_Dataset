import os
import sys
import cv2
import argparse
import numpy as np
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import seaborn as sns

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'lib'))

import torch
import torch.utils.data

from datasets.coco import COCO_MEAN, COCO_STD, COCO_NAMES
from datasets.pascal import VOC_MEAN, VOC_STD, VOC_NAMES

from nets.hg import get_hg_base
from nets.hg_attn import get_hg_attn
from nets.hg_light import get_hg_light
from nets.hg_attn_light import get_hg_attn_light
from nets.resnet import get_pose_net as get_resnet

from utils.utils import load_model
from utils.image import transform_preds, get_affine_transform
from utils.post_process import ctdet_decode

import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

import matplotlib

matplotlib.use('TkAgg')


COCO_COLORS = sns.color_palette('hls', len(COCO_NAMES))
VOC_COLORS = sns.color_palette('hls', len(VOC_NAMES))

# Training settings
parser = argparse.ArgumentParser(description='centernet')

parser.add_argument('--root_dir', type=str, default='./')
parser.add_argument('--img_dir', type=str, default='./.bmp')
parser.add_argument('--ckpt_dir', type=str, default='./.t7')

parser.add_argument('--arch', type=str, default='small'+'hg_attn_light')
parser.add_argument('--dataset', type=str, default='pascal')
parser.add_argument('--img_size', type=int, default=512)

parser.add_argument('--test_flip', action='store_true')
parser.add_argument('--test_scales', type=str, default='1')

parser.add_argument('--test_topk', type=int, default=100)

cfg = parser.parse_args()

os.chdir(cfg.root_dir)

cfg.test_scales = [float(s) for s in cfg.test_scales.split(',')]


def main():
  cfg.device = torch.device('cuda')
  torch.backends.cudnn.benchmark = False

  max_per_image = 100

  image = cv2.imread(cfg.img_dir)
  # orig_image = image
  height, width = image.shape[0:2]
  padding = 127 if 'hg' in cfg.arch else 31
  imgs = {}
  for scale in cfg.test_scales:
    new_height = int(height * scale)
    new_width = int(width * scale)

    if cfg.img_size > 0:
      img_height, img_width = cfg.img_size, cfg.img_size
      center = np.array([new_width / 2., new_height / 2.], dtype=np.float32)
      scaled_size = max(height, width) * 1.0
      scaled_size = np.array([scaled_size, scaled_size], dtype=np.float32)
    else:
      img_height = (new_height | padding) + 1
      img_width = (new_width | padding) + 1
      center = np.array([new_width // 2, new_height // 2], dtype=np.float32)
      scaled_size = np.array([img_width, img_height], dtype=np.float32)

    img = cv2.resize(image, (new_width, new_height))
    trans_img = get_affine_transform(center, scaled_size, 0, [img_width, img_height])
    img = cv2.warpAffine(img, trans_img, (img_width, img_height), flags=cv2.INTER_NEAREST)

    img = img.astype(np.float32) / 255.
    img -= np.array(COCO_MEAN if cfg.dataset == 'coco' else VOC_MEAN, dtype=np.float32)[None, None, :]
    img /= np.array(COCO_STD if cfg.dataset == 'coco' else VOC_STD, dtype=np.float32)[None, None, :]
    img = img.transpose(2, 0, 1)[None, :, :, :]  # from [H, W, C] to [1, C, H, W]

    if cfg.test_flip:
      img = np.concatenate((img, img[:, :, :, ::-1].copy()), axis=0)

    imgs[scale] = {'image': torch.from_numpy(img).float(),
                   'center': np.array(center),
                   'scale': np.array(scaled_size),
                   'fmap_h': np.array(img_height // 4),
                   'fmap_w': np.array(img_width // 4)}

  print('Creating model...')
  if 'hg_base' in cfg.arch:
    model = get_hg_base[cfg.arch]
  elif 'hg_attn' in cfg.arch:
    model = get_hg_attn[cfg.arch]
  elif 'hg_light' in cfg.arch:
    model = get_hg_light[cfg.arch]
  elif 'hg_attn_light' in cfg.arch:
    model = get_hg_attn_light[cfg.arch]
  else:
    raise NotImplementedError

  model = load_model(model, cfg.ckpt_dir)
  model = model.to(cfg.device)
  model.eval()

  with torch.no_grad():
    detections = []
    for scale in imgs:
      imgs[scale]['image'] = imgs[scale]['image'].to(cfg.device)

      output = model(imgs[scale]['image'])[-1]
      dets = ctdet_decode(*output, K=cfg.test_topk)
      dets = dets.detach().cpu().numpy().reshape(1, -1, dets.shape[2])[0]

      top_preds = {}
      dets[:, :2] = transform_preds(dets[:, 0:2],
                                    imgs[scale]['center'],
                                    imgs[scale]['scale'],
                                    (imgs[scale]['fmap_w'], imgs[scale]['fmap_h']))
      dets[:, 2:4] = transform_preds(dets[:, 2:4],
                                     imgs[scale]['center'],
                                     imgs[scale]['scale'],
                                     (imgs[scale]['fmap_w'], imgs[scale]['fmap_h']))
      cls = dets[:, -1]
      for j in range(80):
        inds = (cls == j)
        top_preds[j + 1] = dets[inds, :5].astype(np.float32)
        top_preds[j + 1][:, :4] /= scale

      detections.append(top_preds)

    bbox_and_scores = {}
    for j in range(1, 81 if cfg.dataset == 'coco' else 21):
      bbox_and_scores[j] = np.concatenate([d[j] for d in detections], axis=0)
      # if len(cfg.test_scales) > 1:
      #   soft_nms(bbox_and_scores[j], Nt=0.5, method=2)
    scores = np.hstack([bbox_and_scores[j][:, 4] for j in range(1, 81 if cfg.dataset == 'coco' else 21)])

    if len(scores) > max_per_image:
      kth = len(scores) - max_per_image
      thresh = np.partition(scores, kth)[kth]
      for j in range(1, 81 if cfg.dataset == 'coco' else 21):
        keep_inds = (bbox_and_scores[j][:, 4] >= thresh)
        bbox_and_scores[j] = bbox_and_scores[j][keep_inds]

    # plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    # plt.show()
    fig = plt.figure(0)
    colors = COCO_COLORS if cfg.dataset == 'coco' else VOC_COLORS
    names = COCO_NAMES if cfg.dataset == 'coco' else VOC_NAMES
    plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    for lab in bbox_and_scores:
      for boxes in bbox_and_scores[lab]:
        x1, y1, x2, y2, score = boxes
        if score > 0.05:
          plt.gca().add_patch(Rectangle((x1, y1), x2 - x1, y2 - y1,
                                        linewidth=2, edgecolor=colors[lab], facecolor='none'))
          plt.text(x1 + 3, y1 + 3, names[lab] + '%.2f' % score,
                   bbox=dict(facecolor=colors[lab], alpha=0.5), fontsize=7, color='k')

    fig.patch.set_visible(False)
    plt.axis('off')
    plt.savefig('/.png', dpi=300, transparent=True)
    plt.show()


if __name__ == '__main__':
  main()
